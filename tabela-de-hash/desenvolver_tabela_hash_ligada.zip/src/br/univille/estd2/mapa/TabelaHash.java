package br.univille.estd2.mapa;

/**
 * Esta implementação utiliza a chave
 * como índice direto no arranjo.
 * Possui uma capacidade fixa. Neste exemplo 100.
 */
public class TabelaHash implements Mapa{

    private int tamanho;
    private Integer[] tabela;
    private int capacidade;


    public TabelaHash(){
        this.tamanho = 0;
        this.capacidade = 100;
        this.tabela = new Integer[this.capacidade];
    }

    @Override
    public void adicionar(int chave, int valor) {
        if(chave < this.capacidade){
            this.tabela[chave] = valor;
            tamanho++;
        }
    }

    @Override
    public int remover(int chave) {
        if(!contemChave(chave)){ throw  new RuntimeException("Chave não encontrada"); }
        var valor = this.tabela[chave];
        this.tabela[chave] = null;
        tamanho--;
        return valor;
    }

    @Override
    public int obter(int chave) {
        if(!contemChave(chave)){ throw  new RuntimeException("Chave não encontrada"); }
        return tabela[chave];
    }

    @Override
    public boolean contemChave(int chave) {
        return tabela[chave] != null;
    }

    @Override
    public int tamanho() {
        return tamanho;
    }

    @Override
    public boolean estaVazio() {
        return tamanho == 0;
    }
}
