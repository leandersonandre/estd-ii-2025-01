package br.univille.estd2.mapa;

import java.util.LinkedList;

public class TabelaHashLigada implements Mapa{

    private LinkedList<Entrada> tabela[];
    private int capacidade;

    public TabelaHashLigada() {
        capacidade = 100;
        tabela = new LinkedList[capacidade];
    }

    @Override
    public void adicionar(int chave, int valor) {

    }

    @Override
    public int remover(int chave) {
        return -1;
    }

    @Override
    public int obter(int chave) {
        return -1;
    }

    @Override
    public boolean contemChave(int chave) {
        return false;
    }

    @Override
    public int tamanho() {
        return -1;
    }

    @Override
    public boolean estaVazio() {
        return false;
    }

    record Entrada(int chave, int valor){
    }

}
