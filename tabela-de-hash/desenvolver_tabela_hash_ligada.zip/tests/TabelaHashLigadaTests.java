import br.univille.estd2.mapa.Mapa;
import br.univille.estd2.mapa.TabelaHashLigada;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TabelaHashLigadaTests {

    @Test
    public void testNovaTabelaHash(){
        Mapa m = new TabelaHashLigada();
        boolean vazio = m.estaVazio();
        int tamanho = m.tamanho();
        Assertions.assertEquals(true
                , vazio,"A tabela deve estar vazio.");
        Assertions.assertEquals(0
                , tamanho,"A tabela deve ter o tamanho zero.");
    }

    @Test
    public void testNovaTabelaHashComTamanho1(){
        Mapa m = new TabelaHashLigada();
        m.adicionar(1,10);
        boolean vazio = m.estaVazio();
        int tamanho = m.tamanho();
        Assertions.assertEquals(false
                , vazio,"A tabela não deve estar vazio.");
        Assertions.assertEquals(1
                , tamanho,"A tabela deve ter o tamanho 1.");
    }

    @Test
    public void testObterOElementoDeUmaTabelaComTamanho1(){
        Mapa m = new TabelaHashLigada();
        m.adicionar(1,10);
        boolean existeChave = m.contemChave(1);
        int elemento = m.obter(1);
        Assertions.assertEquals(true
                , existeChave,"A tabela deve conter a chave 1.");
        Assertions.assertEquals(10
                , elemento,"O elemento 10 deve estar associado a chave 1.");
    }

    @Test
    public void testRemoverElementoDeUmaTabelaComTamanho1(){
        Mapa m = new TabelaHashLigada();
        m.adicionar(1,10);
        int elemento = m.remover(1);
        boolean existeChave = m.contemChave(1);
        boolean vazio = m.estaVazio();
        Assertions.assertEquals(false
                , existeChave,"A tabela não deve conter a chave 1.");
        Assertions.assertEquals(10
                , elemento,"O elemento 10 deve retornar ao excluir a chave 1.");
        Assertions.assertEquals(true
                , vazio,"A tabela deve estar vazio.");
    }

    @Test
    public void testAdicionarUmaChaveMaiorQueOTamanhoDoVetor(){
        Mapa m = new TabelaHashLigada();
        m.adicionar(101,10);
        int elemento = m.obter(101);
        boolean existeChave = m.contemChave(1);
        Assertions.assertEquals(true
                , existeChave,"A tabela  deve conter a chave 101.");
        Assertions.assertEquals(10
                , elemento,"O elemento 10 deve estar associado a chave 1.");
    }

    @Test
    public void testColisaoDeHashVetor(){
        Mapa m = new TabelaHashLigada();
        m.adicionar(1,99);
        m.adicionar(101,10);
        m.adicionar(201,77);
        Assertions.assertEquals(true
                , m.contemChave(1),"A tabela  deve conter a chave 101.");
        Assertions.assertEquals(true
                , m.contemChave(101),"A tabela  deve conter a chave 101.");
        Assertions.assertEquals(true
                , m.contemChave(201),"A tabela  deve conter a chave 201.");
        Assertions.assertEquals(99
                , m.obter(1),"O elemento 99 deve estar associado a chave 1.");
        Assertions.assertEquals(10
                , m.obter(101),"O elemento 10 deve estar associado a chave 101.");
        Assertions.assertEquals(77
                , m.obter(1),"O elemento 77 deve estar associado a chave 1.");
    }

}